package it;

import java.io.*;
import java.net.*;

public class Client {
    String nomeServer = "localhost";
    int portaServer = 6789;
    Socket miosocket;
    BufferedReader tastiera;
    String stringaUtente;
    String stringaRicevutaDaSer;
    DataOutputStream outVersoSer;
    BufferedReader inDalSer;
    
    public Socket connetti() {
        System.out.println("client in esecuzione...");
        try{
            tastiera=new BufferedReader(new InputStreamReader(System.in));

            miosocket=new Socket(nomeServer,portaServer);

            outVersoSer=new DataOutputStream(miosocket.getOutputStream());

            inDalSer = new BufferedReader(new InputStreamReader(miosocket.getInputStream()));
            
        }catch(UnknownHostException e){
            System.err.println("non funge un nulla");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            System.out.println("Errore durante connessione");
            System.exit(1);
        }
        return miosocket;
    }

    public void comunica(){
       for(;;){
           try{
            System.out.println("utente, inserisci una stringa: ");
            stringaUtente = tastiera.readLine();

            System.out.println("invio stringa al server...");
            outVersoSer.writeBytes(stringaUtente+'\n');

            stringaRicevutaDaSer = inDalSer.readLine();
            System.out.println("risposta dal sever: "+'\n'+stringaRicevutaDaSer );
                if(stringaUtente.equals("FINE")){
                    System.out.println("chiusura della connesione...");
                    miosocket.close();
                    break;

                }
            }
    
            catch(Exception e){
            System.out.println(e.getMessage());
            System.out.println("Errore durante connessione");
            System.exit(1);
            }
        }
    }

}
