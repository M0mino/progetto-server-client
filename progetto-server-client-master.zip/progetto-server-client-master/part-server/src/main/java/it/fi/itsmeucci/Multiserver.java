package it.fi.itsmeucci;

import java.net.ServerSocket;
import java.net.Socket;

public class Multiserver{

    public void momo(){
        try{
            ServerSocket serverSocket =new ServerSocket(6789);
            for(;;){
                System.out.println("-> il server è in attesa");
                Socket socket = serverSocket.accept();
                System.out.println("server socket "+socket);
                server serverThead = new server(socket);
                serverThead.start();
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage()+ " errore fatele nel server 1");
            System.exit(1);
        }
    }

}