package it.fi.itsmeucci;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class server extends Thread{

    ServerSocket server =null;
    Socket client =null;
    String StringaRicevuta =null;
    String StringMandata = null;
    BufferedReader input;
    DataOutputStream output;


    public server(Socket socket) {
        client= socket;
    }

    public void run(){
        try{
            comunica();
        }
        catch(Exception e){
            e.printStackTrace(System.out);
        }
    }

    public void comunica() throws IOException{
        BufferedReader inDalClinet = new BufferedReader(new InputStreamReader(client.getInputStream()));
        DataOutputStream outVersoClient = new DataOutputStream(client.getOutputStream());
        for(;;){
            StringaRicevuta = inDalClinet.readLine();
            if(StringaRicevuta == null || StringaRicevuta.equals("(FINE COMUNICAZIONE)")){
                outVersoClient.writeBytes(StringaRicevuta+"(-> server in chiusura)"+'\n');
                System.out.println("(echo sul server in chiusura)"+ StringaRicevuta);
                break;
            }
            else{
                outVersoClient.writeBytes(StringaRicevuta+"(ricevuta e trasessa)"+'\n');
                System.out.println("echo sul server: " + StringaRicevuta);
            }
        }

        outVersoClient.close();
        inDalClinet.close();
        System.out.println("CHIUSURA DEL SOCKET");
        client.close();

    }

    

    

}