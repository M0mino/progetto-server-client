package it.fi.itsmeucci;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Multiserver tcpserver = new Multiserver();
       tcpserver.momo();

    } 
}
